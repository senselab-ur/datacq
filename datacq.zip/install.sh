#!/usr/bin/bash

echo "installing dependencies..."
sudo pip install -r requirements.txt
