# datacq
data acquisition system with raspberry pi + arduino + mysql

# installation

- ./install.sh

- python datacq.py 




